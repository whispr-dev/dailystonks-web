# DailyStonks Web 1.0.0

A self-hosted, single-page market observatory for **dailystonks.org**. S&P 500
candles, SPY and Bitcoin price lines share a percentage-return scale, accompanied
by S&P volume, ten-step linear forecasts, model bands and a scrolling quote tape.

## Deploy from your Windows computer

Requires PowerShell 7, Windows OpenSSH (`ssh` and `scp`), `tar`, and your working
**nyc1** SSH alias. Your existing alias selects the correct key, IP, port and user;
the deployment does not edit SSH configuration.

From the extracted `dailystonks-web` directory:

```powershell
.\Deploy.ps1
```

The script uploads the included payload, verifies its SHA-256 on the server,
opens an interactive SSH terminal for sudo, installs a dedicated systemd service,
backs up affected configuration, validates Caddy, then reloads it. Enter your
**server user's sudo password** if asked. No Python or Node installation is
needed on your Windows computer for deployment.

The target is an **existing Ubuntu 22.04+ / Debian host** with Python 3.10+,
Caddy and systemd already installed and running. It uses
`/etc/caddy/Caddyfile` by default. It checks Caddy's actual systemd startup and
reload commands before changing anything. For a different Caddyfile:

```powershell
.\Deploy.ps1 -Caddyfile /path/to/your/Caddyfile
```

Read-only preflight is available if needed:

```powershell
.\Deploy.ps1 -Audit
```

The installer supports ordinary explicit Caddy site blocks and top-level file
imports/globs. It removes only the `dailystonks.org` and `www.dailystonks.org`
addresses from existing blocks, preserving other addresses and their handlers.
It installs its new route in `/etc/dailystonks-web/Caddyfile` and imports that
file from the main configuration. Complex configurations, heredocs, dynamic
imports or brace-less site syntax are refused before mutation. The audit output
can be used to adapt such a configuration deliberately.

**DNS:** `dailystonks.org` must point to NYC1. An AAAA record, if present, must
also reach the server. Caddy needs reachable TCP ports 80 and 443 to serve the
site and obtain its TLS certificate. No DNS records or firewall rules are edited.
`www.dailystonks.org` redirects to the apex if its DNS is configured.

The installer prints the backup path. Deployment failures automatically restore
configuration and the previous managed service state. To restore a successful
deployment later, pass the **exact printed backup path**:

```powershell
$backup = Read-Host 'Paste the Rollback backup path printed by deployment'
.\Deploy.ps1 -Rollback $backup
```

Rollback restores the files that deployment touched. Use it before later unrelated
manual edits to those same Caddy files, because it restores their saved bytes.
Release files and market-cache data are retained for diagnosis.

After installation, the launcher checks the public `/api/health` endpoint. A
successful server install with an unverified public endpoint is reported explicitly;
it usually needs DNS propagation or certificate issuance. It is not claimed live
until that public check passes.

## What runs on NYC1

| Item | Location |
| --- | --- |
| Dedicated service | `dailystonks-web.service` |
| Unprivileged account | `dailystonks-www` |
| Versioned application | `/opt/dailystonks-web/releases/` |
| Active release symlink | `/opt/dailystonks-web/current` |
| Configuration | `/etc/dailystonks-web/config.json` |
| Caddy site fragment | `/etc/dailystonks-web/Caddyfile` |
| Last-good market data | `/var/lib/dailystonks-web/last-good.json` |
| Rollback backups | `/var/backups/dailystonks-web/` |
| Private HTTP listener | `127.0.0.1:8794` |

The old DailyStonks process, if any, is not stopped or deleted. Its domain is
routed to the new service. Other domains keep their existing handlers. The new
service restarts on failure and starts at boot. It is limited to 256 MB and runs
with a read-only filesystem except its own data directory, without root privileges.

Useful commands from Windows:

```powershell
ssh nyc1 "systemctl status dailystonks-web --no-pager"
ssh nyc1 "sudo journalctl -u dailystonks-web -n 60 --no-pager"
ssh nyc1 "sudo journalctl -u caddy -n 40 --no-pager"
Invoke-RestMethod https://dailystonks.org/api/health
```

## Data: what “live” means here

The browser reads a shared server snapshot every 15 seconds. The server polls
eight allowlisted symbols **every 60 seconds**, regardless of visitor count:
S&P 500, SPY, Bitcoin, Nasdaq 100, Dow Jones, Apple, NVIDIA and Ethereum. Each
poll merges the latest daily OHLC candles with stored history. One-year chart
history is refreshed every 15 minutes. There is no paid streaming feed and no
promise of tick-by-tick or exchange-real-time prices. Individual quote timestamps
and session status remain visible. Refresh reloads the shared snapshot; it does
not bypass upstream polling limits.

The default adapter calls the Yahoo Finance chart endpoint used by the original
mini app's data-source ecosystem. **Its availability is best-effort, and public
redistribution rights are not supplied by this software.** yfinance's documentation
describes Yahoo Finance data access as personal-use/research-oriented:
https://ranaroussi.github.io/yfinance/
Confirm appropriate rights or replace the adapter with a licensed public-display
feed before operating it as a public data service. No API key is needed for this
default adapter. No scraping-cookie or rate-limit bypass is attempted.

Failures preserve last-good data and produce visible degraded/stale notices.
The first launch displays a loading or unavailable state until real data arrives.
The package contains **no sample market data** and never generates fake prices.
Closing a visitor's browser does not stop the server's polling.

The API is deliberately read-only and fixed-scope. It cannot fetch arbitrary URLs
or visitor-supplied symbols. No client-side third-party scripts, fonts, cookies,
analytics or browser storage are used. Visitors contact your server only. Your
web server's access logging configuration remains under your control.

## Overlay and projections

All three instruments use their close on the first common visible date as a base:

```text
percentage move = 100 × (price / base close − 1)
```

Dates use a real UTC calendar axis; Bitcoin retains its weekend observations.
The S&P layer uses candles; SPY and Bitcoin use lines. Toggling cards changes
visibility without changing the common base. The range selector changes it.
Prices are raw daily OHLC/close values, not dividend-adjusted total returns.

Forecasts fit ordinary least squares to the latest **60 completed daily closes**
or all available observations if at least five exist. For observations `x=0..n−1`:

```text
fit(x) = intercept + slope × x
s = sqrt(sum((close − fit(x))²) / (n − 2))
band(x) = fit(x) ± 1.96 × s × sqrt(1 + 1/n + (x − mean(x))² / Sxx)
```

The band is an approximate normal-model prediction interval for a future
observation. It is **not calibrated market uncertainty**. Prices need not obey
the model, and projections can be economically implausible, including negative.
This is transparent trend extrapolation, not an AI price oracle.

The current incomplete daily bar is excluded. Equities advance ten **weekdays**;
market holidays are not excluded. Crypto advances ten **calendar days**. These
different horizons are intentional. The dashed fit can jump away from the last
close because it is a regression prediction, not a line forcibly anchored there.
Outlook percentages compare the forecast endpoint to the last completed close.

## Run or modify locally

Runtime: **Python 3.10 or newer, standard library only**. No npm/pip dependencies,
frontend build, framework or CDN. Node is optional for a JavaScript syntax check.

Windows:

```powershell
py -3 .\app\server.py
```

Linux:

```bash
python3 app/server.py
```

Open **http://127.0.0.1:8794**. Press Ctrl+C to stop. An explicit configuration
example is included; use `--config config.example.json` to load it. The default
listener is loopback only. `--host 0.0.0.0` is available for controlled development
previews; the installed service does not use it.

Run the contract checks:

```powershell
py -3 -m unittest discover -s tests -v
```

```bash
python3 -m unittest discover -s tests -v
node --check public/app.js
```

Linux also exercises Caddy parsing, archive safety and backup restoration. These
installer-specific tests are skipped on Windows because the deployment script
uses Linux account/locking modules. No test alters your real system configuration.
Live upstream access, sudo, DNS and TLS issuance must still be checked on NYC1;
the PowerShell launcher and installer perform those applicable deployment checks.

After editing source, rebuild the deployment payload using the standard library:

```powershell
py -3 .\Package.py
.\Deploy.ps1
```

```bash
python3 Package.py
```

## Source layout

| Path | Purpose |
| --- | --- |
| `public/index.html` | Complete page and accessible controls |
| `public/style.css` | Responsive dark theme |
| `public/app.js` | Canvas chart, tape, tooltips and CSV export |
| `public/favicon.svg` | Site icon |
| `public/robots.txt` | Crawler access |
| `app/market.py` | Provider parsing, validation and forecast math |
| `app/server.py` | HTTP server, shared polling and last-good cache |
| `deploy/install.py` | Transactional Linux installer and rollback |
| `Deploy.ps1` | Windows/PowerShell SSH launcher |
| `Package.py` | Rebuilds the deployment archive |
| `tests/test_contracts.py` | Data, math, HTTP and installer contract tests |
| `site.tar.gz` | Ready-to-upload runtime payload |
| `config.example.json` | Optional local settings |

Original attached mini software remains unmodified. This website is a new,
dependency-free implementation of the requested view.

© 2026 whispr.dev. Code under the included MIT license. Provider data and third-party
trademarks retain their respective rights.
