"""Contract tests: maths, feed parsing, shared cache, HTTP boundary and deployment safety."""
import datetime as dt
import importlib.util
import io
import json
import math
from pathlib import Path
import sys
import tarfile
import tempfile
import threading
from types import SimpleNamespace
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))
from market import UTC, ASSETS, add_projection, parse_chart, projection
from server import BoundedServer, Handler, MarketStore

installer = None
if sys.platform != "win32":
    spec = importlib.util.spec_from_file_location("installer", ROOT / "deploy" / "install.py")
    installer = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = installer
    spec.loader.exec_module(installer)


def asset(key="SPX"):
    start = dt.date(2026, 1, 1)
    bars = [{"date": (start + dt.timedelta(days=i)).isoformat(), "open": 100+i,
             "high": 102+i, "low": 99+i, "close": 101+i, "volume": 1000+i} for i in range(80)]
    return {"key": key, **ASSETS[key], "bars": bars,
            "quote": {"price": 180, "change_pct": 1, "time": 1790000000,
                      "session_start": 1790000000, "session_end": 1790020000}}


class MathTests(unittest.TestCase):
    def test_exact_line_and_prediction(self):
        bars = asset()["bars"]
        result = projection(bars, "crypto")
        self.assertEqual(result["observations"], 60)
        self.assertAlmostEqual(result["slope"], 1)
        self.assertAlmostEqual(result["points"][0]["close"], 181)
        self.assertAlmostEqual(result["points"][-1]["close"], 190)
        self.assertAlmostEqual(result["points"][-1]["low"], 190)

    def test_bands_widen_and_contain_fit(self):
        bars = asset()["bars"]
        for i, bar in enumerate(bars):
            bar["close"] += (-1) ** i * 4
        result = projection(bars, "etf")["points"]
        self.assertGreater(result[-1]["high"]-result[-1]["low"], result[0]["high"]-result[0]["low"])
        for point in result:
            self.assertLess(point["low"], point["close"])
            self.assertGreater(point["high"], point["close"])

    def test_equities_skip_weekends_crypto_does_not(self):
        bars = asset()["bars"]
        # 20 March 2026 is a Friday.
        bars[-1]["date"] = "2026-03-20"
        self.assertEqual(projection(bars, "etf")["points"][0]["date"], "2026-03-23")
        self.assertEqual(projection(bars, "crypto")["points"][0]["date"], "2026-03-21")

    def test_incomplete_daily_candle_not_fitted(self):
        value = asset("BTC")
        now = dt.datetime.fromisoformat(value["bars"][-1]["date"]).replace(tzinfo=UTC, hour=12)
        result = add_projection(value, now)
        self.assertEqual(result["forecast"]["last_date"], value["bars"][-2]["date"])

    def test_insufficient_or_nonfinite_data(self):
        bars = asset()["bars"]
        self.assertIsNone(projection(bars[:4], "etf"))
        bars[-1]["close"] = math.nan
        self.assertIsNone(projection(bars, "etf"))


class FeedTests(unittest.TestCase):
    def payload(self):
        return {"chart": {"result": [{"meta": {"regularMarketPrice": 110, "regularMarketTime": 1767398400},
            "timestamp": [1767225600,1767312000,1767398400], "indicators": {"quote": [{
            "open": [99,100,None], "high": [101,112,115], "low": [98,99,109],
            "close": [100,110,114], "volume": [10,None,20]}]}}], "error": None}}

    def test_nulls_and_previous_close(self):
        result = parse_chart(self.payload(), "SPY")
        self.assertEqual(len(result["bars"]),2)
        self.assertIsNone(result["bars"][1]["volume"])
        # Quote dated Jan 3: the latest valid previous daily close is Jan 2.
        self.assertAlmostEqual(result["quote"]["change_pct"],0)

    def test_invalid_ohlc_and_errors_rejected(self):
        payload = self.payload()
        payload["chart"]["result"][0]["indicators"]["quote"][0]["high"]=[1,1,1]
        with self.assertRaises(ValueError):parse_chart(payload,"SPY")
        with self.assertRaises(ValueError):parse_chart({"chart":{"error":{"code":"Denied"}}},"SPY")

    def test_quoted_change_is_not_confused_with_history_range_change(self):
        payload=self.payload()
        meta=payload["chart"]["result"][0]["meta"]
        meta["regularMarketChangePercent"]=0.201
        meta["chartPreviousClose"]=50
        self.assertEqual(parse_chart(payload,"BTC")["quote"]["change_pct"],0.201)

    def test_shared_cache_retains_last_good_and_recovers_history(self):
        with tempfile.TemporaryDirectory() as temp:
            store = MarketStore(Path(temp))
            with patch("server.fetch_asset",side_effect=lambda key, history:asset(key)) as fetch:
                store.poll(True)
                self.assertEqual(fetch.call_count,len(ASSETS))
            before = store.snapshot()["assets"][0]["bars"]
            with patch("server.fetch_asset",side_effect=ValueError("Provider HTTP 429")):
                store.poll(False)
            self.assertEqual(store.snapshot()["assets"][0]["bars"],before)
            self.assertIn("SPX",store.errors)
            reloaded = MarketStore(Path(temp))
            self.assertEqual(len(reloaded.assets),len(ASSETS))
            reloaded.assets["SPX"].pop("history_fetched_at")
            with patch("server.fetch_asset",side_effect=lambda key,history:asset(key)) as fetch:
                reloaded.poll(False)
                self.assertIn(unittest.mock.call("SPX",True),fetch.call_args_list)


class HTTPTests(unittest.TestCase):
    def test_routes_no_open_proxy_and_security_headers(self):
        with tempfile.TemporaryDirectory() as temp:
            server = BoundedServer(("127.0.0.1",0),Handler,MarketStore(Path(temp)))
            thread = threading.Thread(target=server.serve_forever,daemon=True)
            thread.start()
            base = f"http://127.0.0.1:{server.server_port}"
            try:
                with urllib.request.urlopen(base+"/") as response:
                    self.assertIn("frame-ancestors 'none'",response.headers["Content-Security-Policy"])
                    self.assertIn(b"The market overlay",response.read())
                with urllib.request.urlopen(base+"/api/market?symbol=arbitrary") as response:
                    self.assertEqual(json.load(response)["assets"],[])
                for path in ("/../app/server.py","/config.json","/data/last-good.json","/api/fetch?url=http://localhost"):
                    with self.assertRaises(urllib.error.HTTPError) as error:
                        urllib.request.urlopen(base+path)
                    self.assertEqual(error.exception.code,404)
                request = urllib.request.Request(base+"/api/health",method="HEAD")
                with urllib.request.urlopen(request) as response:self.assertEqual(response.read(),b"")
            finally:
                server.shutdown();server.server_close();thread.join()


@unittest.skipIf(sys.platform == "win32", "Linux installer contracts; run these on Linux")
class DeploymentTests(unittest.TestCase):
    def test_remove_only_domain_and_keep_nested_other_site(self):
        source = '''# keep this\n{
 email owner@example.net
}
(safe) {
 header X-Test "} {"
}
other.org, dailystonks.org, www.dailystonks.org {
 handle /app/* {
  reverse_proxy localhost:1234
 }
}
elsewhere.org {
 respond `hello { world }`
}
'''
        result = installer.remove_target_blocks(source)
        self.assertIn('other.org {',result)
        self.assertIn('handle /app/* {',result)
        self.assertIn('elsewhere.org {\n respond `hello { world }`\n}',result)
        self.assertNotIn('www.dailystonks.org',result)
        self.assertIn('header X-Test "} {"',result)

    def test_separate_http_https_blocks_removed_other_domain_untouched(self):
        source = 'https://dailystonks.org {\n respond "old"\n}\nhttp://www.dailystonks.org {\n redir https://dailystonks.org{uri}\n}\nother.org {\n respond "OK"\n}\n'
        result = installer.remove_target_blocks(source)
        self.assertNotIn('respond "old"',result)
        self.assertIn('other.org {\n respond "OK"\n}',result)

    def test_import_tree_and_noop(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)/"Caddyfile"
            root.write_text('import sites/*\n')
            (root.parent/"sites").mkdir()
            child=root.parent/"sites"/"a.caddy"
            child.write_text('other.org {\n respond "a#b"\n}\n')
            configs=installer.collect_configs(root)
            self.assertEqual(len(configs),2)
            self.assertEqual(installer.remove_target_blocks(child.read_text()),child.read_text())

    def test_complex_sources_refused(self):
        for source in ('dailystonks.org\nreverse_proxy localhost:8080\n','import {$CONFIG}\n','dailystonks.org {\n respond <<HTML\n hello\n HTML\n}\n'):
            with self.assertRaises(RuntimeError):installer.parse_top_level(source)

    def test_archive_traversal_and_symlinks_refused(self):
        for name,kind in (("../escape",tarfile.REGTYPE),("escape",tarfile.SYMTYPE)):
            with tempfile.TemporaryDirectory() as temp:
                archive=Path(temp)/"bad.tar.gz"
                with tarfile.open(archive,"w:gz") as tar:
                    info=tarfile.TarInfo(name);info.type=kind;info.linkname="/etc/passwd";tar.addfile(info,io.BytesIO())
                with self.assertRaises(RuntimeError):installer.safe_extract(archive,Path(temp)/"out")

    def test_backup_and_rollback_restore_bytes_and_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            base=Path(temp)/"opt";base.mkdir()
            backup_root=Path(temp)/"backups"
            config=Path(temp)/"Caddyfile";config.write_text('other.org {\n respond "untouched"\n}\n')
            original=config.read_bytes();config.chmod(0o640)
            unit=Path(temp)/"unit.service";new_file=Path(temp)/"new.caddy"
            (base/"current").symlink_to("releases/old")
            class Result:
                returncode=1
                stdout=""
                stderr=""
            with patch.object(installer,"BASE",base),patch.object(installer,"BACKUPS",backup_root),patch.object(installer,"run",return_value=Result()) as commands:
                backup=installer.backup([config,unit,new_file],config)
                config.write_text('changed');unit.write_text('new unit');new_file.write_text('new route')
                installer.link_current("releases/new")
                installer.restore(backup)
                self.assertEqual(config.read_bytes(),original)
                self.assertEqual(config.stat().st_mode&0o777,0o640)
                self.assertEqual((base/"current").readlink(),Path("releases/old"))
                self.assertFalse(unit.exists());self.assertFalse(new_file.exists())
                self.assertTrue(any(call.args[0][:2]==["caddy","validate"] for call in commands.call_args_list))

    def test_failed_reload_rolls_back_complete_install_transaction(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            paths={"BASE":root/"opt","BACKUPS":root/"backups","UNIT":root/"unit.service",
                   "CONFIG":root/"etc"/"config.json","SNIPPET":root/"etc"/"Caddyfile","STATE":root/"state"}
            caddyfile=root/"Caddyfile"
            source='other.org {\n respond "keep"\n}\ndailystonks.org {\n reverse_proxy localhost:9000\n}\n'
            caddyfile.write_text(source)
            archive=root/"site.tar.gz"
            with tarfile.open(archive,"w:gz") as tar:
                for name in ("app/server.py","app/market.py","public/index.html","public/app.js","public/style.css"):
                    info=tarfile.TarInfo(name);info.size=1;tar.addfile(info,io.BytesIO(b"x"))
            args=SimpleNamespace(caddyfile=caddyfile,archive=archive,audit=False,
                                 sha256=installer.hashlib.sha256(archive.read_bytes()).hexdigest())
            reloads=[]
            def command(argv,check=True):
                argv=[str(arg) for arg in argv]
                if argv[:2]==["systemctl","show"]:
                    return SimpleNamespace(returncode=0,stdout=str(caddyfile),stderr="")
                if argv[:2]==["systemctl","reload"]:
                    reloads.append(argv)
                    if len(reloads)==1:raise RuntimeError("Injected reload failure")
                inactive=argv[:2] in (["systemctl","is-enabled"],["systemctl","is-active"]) and argv[-1]==installer.SERVICE
                return SimpleNamespace(returncode=int(inactive),stdout="",stderr="")
            account=SimpleNamespace(pw_uid=1000,pw_gid=1000)
            with patch.multiple(installer,**paths),patch.object(installer,"run",side_effect=command),patch.object(installer,"health",return_value={"ok":True,"available":[],"errors":{}}),patch.object(installer.shutil,"which",return_value="/usr/bin/tool"),patch.object(installer.pwd,"getpwnam",return_value=account),patch.object(installer.os,"chown"),patch.object(installer.socket,"socket"):
                with self.assertRaisesRegex(RuntimeError,"Injected reload failure"):
                    installer.install(args)
                self.assertEqual(caddyfile.read_text(),source)
                self.assertFalse(paths["UNIT"].exists())
                self.assertFalse(paths["CONFIG"].exists())
                self.assertFalse(paths["SNIPPET"].exists())
                self.assertFalse((paths["BASE"]/"current").exists())
                self.assertEqual(len(reloads),2)


if __name__ == "__main__":
    unittest.main()
