"""Market adapter and ordinary least-squares projections. Python 3.10+, stdlib only."""
from __future__ import annotations

import datetime as dt
import json
import math
import urllib.error
import urllib.parse
import urllib.request

ASSETS = {
    "SPX": {"symbol": "^GSPC", "name": "S&P 500", "kind": "index"},
    "SPY": {"symbol": "SPY", "name": "SPDR S&P 500 ETF", "kind": "etf"},
    "BTC": {"symbol": "BTC-USD", "name": "Bitcoin", "kind": "crypto"},
    "NDX": {"symbol": "^NDX", "name": "Nasdaq 100", "kind": "index"},
    "DJI": {"symbol": "^DJI", "name": "Dow Jones", "kind": "index"},
    "AAPL": {"symbol": "AAPL", "name": "Apple", "kind": "stock"},
    "NVDA": {"symbol": "NVDA", "name": "NVIDIA", "kind": "stock"},
    "ETH": {"symbol": "ETH-USD", "name": "Ethereum", "kind": "crypto"},
}
MAIN = ("SPX", "SPY", "BTC")
UTC = dt.timezone.utc


def finite(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def parse_chart(payload: dict, key: str) -> dict:
    chart = payload.get("chart", {})
    if chart.get("error") or not chart.get("result"):
        raise ValueError("Provider did not return a chart")
    result = chart["result"][0]
    meta = result.get("meta", {})
    quote = result.get("indicators", {}).get("quote", [{}])[0]
    bars = {}
    for index, stamp in enumerate(result.get("timestamp", [])):
        if not finite(stamp):
            continue
        values = [quote.get(field, [])[index] if index < len(quote.get(field, [])) else None
                  for field in ("open", "high", "low", "close")]
        if not all(finite(v) and v > 0 for v in values):
            continue
        opening, high, low, close = values
        if low > min(opening, close) or high < max(opening, close):
            continue
        date = dt.datetime.fromtimestamp(stamp, UTC).date().isoformat()
        volumes = quote.get("volume", [])
        volume = volumes[index] if index < len(volumes) else None
        bars[date] = {"date": date, "open": opening, "high": high, "low": low,
                      "close": close, "volume": volume if finite(volume) and volume >= 0 else None}
    rows = [bars[date] for date in sorted(bars)]
    if not rows:
        raise ValueError("Provider returned no valid OHLC bars")
    price = meta.get("regularMarketPrice")
    stamp = meta.get("regularMarketTime")
    if not finite(price) or price <= 0 or not finite(stamp):
        raise ValueError("Provider returned no timestamped quote")
    quote_date = dt.datetime.fromtimestamp(stamp, UTC).date().isoformat()
    previous = meta.get("previousClose")
    if not finite(previous) or previous <= 0:
        previous_rows = [bar for bar in rows if bar["date"] < quote_date]
        previous = previous_rows[-1]["close"] if previous_rows else None
        if ASSETS[key]["kind"] == "crypto" and previous_rows:
            yesterday = (dt.date.fromisoformat(quote_date) - dt.timedelta(days=1)).isoformat()
            if previous_rows[-1]["date"] != yesterday:
                previous = None
    # The provider's quoted day change is authoritative. A history request's
    # chartPreviousClose can mean the start of the entire range, not yesterday.
    change = meta.get("regularMarketChangePercent")
    if not finite(change):
        change = (price / previous - 1) * 100 if previous else None
    period = meta.get("currentTradingPeriod", {}).get("regular", {})
    return {"key": key, **ASSETS[key], "currency": meta.get("currency", "USD"),
            "bars": rows, "quote": {"price": price, "change_pct": change,
            "time": int(stamp), "session_start": period.get("start"),
            "session_end": period.get("end")}}


def fetch_asset(key: str, history: bool = False) -> dict:
    # Fixed host + allowlisted symbol: visitors cannot turn this into an open proxy.
    symbol = urllib.parse.quote(ASSETS[key]["symbol"], safe="")
    params = urllib.parse.urlencode({"range": "1y" if history else "5d", "interval": "1d"})
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?{params}"
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0",
                                                  "Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            raw = response.read(4_000_001)
            if len(raw) > 4_000_000:
                raise ValueError("Provider response exceeded size limit")
        return parse_chart(json.loads(raw), key)
    except urllib.error.HTTPError as exc:
        raise ValueError(f"Provider HTTP {exc.code}") from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ValueError("Provider connection unavailable") from None


def projection(bars: list[dict], kind: str, days: int = 10, lookback: int = 60) -> dict | None:
    """OLS of close against observation number; approximate normal prediction band.

    Caller supplies completed daily bars. Equities advance on weekdays (holidays
    are not excluded); crypto advances every calendar day. No claim of calibrated
    coverage or investment performance is made.
    """
    sample = bars[-lookback:]
    n = len(sample)
    if n < 5:
        return None
    values = [bar["close"] for bar in sample]
    if not all(finite(v) and v > 0 for v in values):
        return None
    xbar = (n - 1) / 2
    ybar = sum(values) / n
    sxx = sum((x - xbar) ** 2 for x in range(n))
    slope = sum((x - xbar) * (y - ybar) for x, y in enumerate(values)) / sxx
    intercept = ybar - slope * xbar
    error = math.sqrt(sum((y - (intercept + slope * x)) ** 2
                          for x, y in enumerate(values)) / (n - 2))
    date = dt.date.fromisoformat(sample[-1]["date"])
    points = []
    for horizon in range(1, days + 1):
        date += dt.timedelta(days=1)
        while kind != "crypto" and date.weekday() >= 5:
            date += dt.timedelta(days=1)
        x = n - 1 + horizon
        mean = intercept + slope * x
        margin = 1.96 * error * math.sqrt(1 + 1 / n + (x - xbar) ** 2 / sxx)
        points.append({"date": date.isoformat(), "close": mean,
                       "low": mean - margin, "high": mean + margin})
    return {"points": points, "observations": n, "slope": slope,
            "last_date": sample[-1]["date"], "last_close": sample[-1]["close"],
            "calendar": "calendar days" if kind == "crypto" else "weekdays; holidays not excluded"}


def add_projection(asset: dict, now: dt.datetime) -> dict:
    rows = asset["bars"]
    # Daily equity bars close when the supplied regular session ends. Past dates
    # are complete; crypto's current UTC day is always still forming.
    today = now.date().isoformat()
    end = asset["quote"].get("session_end")
    complete = [bar for bar in rows if bar["date"] < today or
                (bar["date"] == today and asset["kind"] != "crypto" and
                 finite(end) and now.timestamp() >= end)]
    return {**asset, "forecast": projection(complete, asset["kind"])}
