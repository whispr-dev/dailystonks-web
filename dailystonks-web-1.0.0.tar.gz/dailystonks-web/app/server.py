#!/usr/bin/env python3
"""DailyStonks Web 1.0.0: shared polling, persistent last-good data, bounded HTTP."""
from __future__ import annotations

import argparse
import concurrent.futures
import datetime as dt
import json
import logging
import os
from pathlib import Path
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

from market import ASSETS, MAIN, UTC, add_projection, fetch_asset

ROOT = Path(__file__).resolve().parent.parent
VERSION = "1.0.0"
LOG = logging.getLogger("dailystonks")


class MarketStore:
    def __init__(self, state_dir: Path, refresh: int = 60, history_refresh: int = 900):
        self.path = state_dir / "last-good.json"
        self.refresh = max(60, refresh)
        self.history_refresh = max(300, history_refresh)
        self.lock = threading.Lock()
        self.assets = {}
        self.errors = {}
        self.last_cycle = None
        self.stop = threading.Event()
        try:
            saved = json.loads(self.path.read_text())
            self.assets = {key: value for key, value in saved.items() if key in ASSETS
                           and isinstance(value, dict) and value.get("bars") and value.get("quote")}
        except (OSError, ValueError, TypeError, AttributeError):
            pass

    def snapshot(self) -> dict:
        now = dt.datetime.now(UTC)
        with self.lock:
            assets = [add_projection(self.assets[key], now) for key in ASSETS if key in self.assets]
            errors = dict(self.errors)
            cycle = self.last_cycle
        return {"version": VERSION, "server_time": now.timestamp(), "last_poll": cycle,
                "refresh_seconds": self.refresh, "source": "Yahoo Finance",
                "delay_notice": "Provider delays apply. Quote time is shown per instrument.",
                "assets": assets, "errors": errors}

    def poll(self, long_history: bool) -> None:
        with self.lock:
            full = {key: key in MAIN and (long_history or not self.assets.get(key, {}).get("history_fetched_at"))
                    for key in ASSETS}
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            jobs = {pool.submit(fetch_asset, key, full[key]): key for key in ASSETS}
            for future in concurrent.futures.as_completed(jobs):
                key = jobs[future]
                try:
                    fresh = future.result()
                    fresh["fetched_at"] = time.time()
                    with self.lock:
                        old = self.assets.get(key)
                        if old and not full[key]:
                            merged = {bar["date"]: bar for bar in old["bars"]}
                            merged.update({bar["date"]: bar for bar in fresh["bars"]})
                            fresh["bars"] = [merged[date] for date in sorted(merged)][-400:]
                            fresh["history_fetched_at"] = old.get("history_fetched_at")
                        else:
                            fresh["history_fetched_at"] = fresh["fetched_at"] if full[key] else None
                        self.assets[key] = fresh
                        self.errors.pop(key, None)
                except Exception as exc:
                    LOG.warning("%s: %s", key, exc)
                    with self.lock:
                        self.errors[key] = {"message": str(exc)[:160], "at": time.time()}
        with self.lock:
            self.last_cycle = time.time()
            encoded = json.dumps(self.assets, allow_nan=False)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(".tmp")
            temporary.write_text(encoded)
            os.replace(temporary, self.path)
        except OSError:
            LOG.exception("Could not persist last-good data")

    def run(self) -> None:
        next_history = 0.0
        while not self.stop.is_set():
            started = time.monotonic()
            long_history = started >= next_history
            self.poll(long_history)
            if long_history:
                next_history = started + self.history_refresh
            self.stop.wait(max(1, self.refresh - (time.monotonic() - started)))


class BoundedServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 32

    def __init__(self, address, handler, store):
        self.slots = threading.BoundedSemaphore(32)
        self.store = store
        super().__init__(address, handler)

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            request.close()
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()


class Handler(BaseHTTPRequestHandler):
    server_version = "DailyStonks"
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, fmt, *args):
        if len(args) > 1 and str(args[1]).startswith(("4", "5")):
            LOG.warning(fmt, *args)

    def respond(self, status, body, mime, head=False):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store" if mime.startswith("application/json") else "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; "
                         "img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        if not head:
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def do_HEAD(self):
        self.do_GET(head=True)

    def do_GET(self, head=False):
        path = urlsplit(self.path).path
        if path == "/api/market":
            body = json.dumps(self.server.store.snapshot(), allow_nan=False).encode()
            return self.respond(200, body, "application/json; charset=utf-8", head)
        if path == "/api/health":
            snapshot = self.server.store.snapshot()
            body = json.dumps({"ok": True, "app": "dailystonks-web", "version": VERSION,
                               "available": [a["key"] for a in snapshot["assets"]],
                               "errors": snapshot["errors"]}).encode()
            return self.respond(200, body, "application/json; charset=utf-8", head)
        files = {"/": ("index.html", "text/html; charset=utf-8"),
                 "/index.html": ("index.html", "text/html; charset=utf-8"),
                 "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                 "/style.css": ("style.css", "text/css; charset=utf-8"),
                 "/favicon.svg": ("favicon.svg", "image/svg+xml"),
                 "/robots.txt": ("robots.txt", "text/plain; charset=utf-8")}
        if path not in files:
            return self.respond(404, b"Not found\n", "text/plain; charset=utf-8", head)
        filename, mime = files[path]
        return self.respond(200, (ROOT / "public" / filename).read_bytes(), mime, head)


def main():
    parser = argparse.ArgumentParser(description="DailyStonks Web")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--port", type=int)
    parser.add_argument("--host", default="127.0.0.1", choices=("127.0.0.1", "0.0.0.0"))
    parser.add_argument("--strictPort", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--state-dir", type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text()) if args.config else {}
    port = args.port or int(config.get("port", 8794))
    state = args.state_dir or Path(config.get("state_dir", ROOT / "data"))
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    store = MarketStore(state, int(config.get("refresh_seconds", 60)),
                        int(config.get("history_refresh_seconds", 900)))
    server = BoundedServer((args.host, port), Handler, store)
    worker = threading.Thread(target=store.run, daemon=True)
    worker.start()

    def shutdown(*_):
        store.stop.set()
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    LOG.info("DailyStonks Web %s — http://127.0.0.1:%s", VERSION, port)
    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        store.stop.set()
        server.server_close()
        worker.join(timeout=2)


if __name__ == "__main__":
    main()
