#requires -Version 7.0
[CmdletBinding()]
param(
    [ValidatePattern('^[A-Za-z0-9_.-]+$')][string]$SshTarget = 'nyc1',
    [ValidatePattern('^/[A-Za-z0-9_./-]+$')][string]$Caddyfile = '/etc/caddy/Caddyfile',
    [switch]$Audit,
    [ValidatePattern('^/var/backups/dailystonks-web/[A-Za-z0-9_-]+$')][string]$Rollback
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$PSNativeCommandUseErrorActionPreference = $false
if ($Audit -and $Rollback) { throw 'Choose either -Audit or -Rollback.' }

function Invoke-Checked {
    param([string]$Executable, [string[]]$Arguments)
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Executable failed with exit code $LASTEXITCODE. Read the output above." }
}

foreach ($command in @('ssh', 'scp', 'tar')) {
    if (-not (Get-Command $command -ErrorAction SilentlyContinue)) { throw "Required command missing: $command" }
}
$archive = Join-Path $PSScriptRoot 'site.tar.gz'
$installer = Join-Path $PSScriptRoot 'deploy/install.py'
if (-not (Test-Path -LiteralPath $installer)) { throw "Installer missing: $installer" }
if (-not $Audit -and -not $Rollback -and -not (Test-Path -LiteralPath $archive)) { throw "Deployment payload missing: $archive" }
$stage = 'dailystonks-upload-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8)
Write-Host "Connecting through your existing SSH alias '$SshTarget'..." -ForegroundColor Cyan
Invoke-Checked -Executable 'ssh' -Arguments @($SshTarget, "mkdir -m 700 -- $stage")
try {
    Invoke-Checked -Executable 'scp' -Arguments @($installer, "${SshTarget}:$stage/install.py")
    $remote = "sudo -- python3 $stage/install.py --caddyfile $Caddyfile"
    if ($Rollback) {
        $remote += " --rollback $Rollback"
    } elseif ($Audit) {
        $remote += ' --audit'
    } else {
        Invoke-Checked -Executable 'scp' -Arguments @($archive, "${SshTarget}:$stage/site.tar.gz")
        $hash = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
        $remote += " --archive $stage/site.tar.gz --sha256 $hash"
    }
    Write-Host 'The server can ask for your sudo password here. SSH has an interactive terminal.' -ForegroundColor Cyan
    Invoke-Checked -Executable 'ssh' -Arguments @('-t', $SshTarget, $remote)
} finally {
    # This directory is unique to this invocation and contains only its upload.
    & ssh $SshTarget "rm -f -- $stage/install.py $stage/site.tar.gz; rmdir -- $stage" 2>$null
}
if (-not $Audit -and -not $Rollback) {
    Write-Host "`nInstalled. Checking the public HTTPS endpoint..." -ForegroundColor Green
    try {
        $health = Invoke-RestMethod -Uri 'https://dailystonks.org/api/health' -TimeoutSec 20
        if ($health.app -ne 'dailystonks-web' -or -not $health.ok) { throw 'The domain is not reaching the new service yet.' }
        Write-Host 'Public HTTPS verified: https://dailystonks.org' -ForegroundColor Green
        Write-Host ('Available feeds: ' + ($health.available -join ', '))
    } catch {
        Write-Warning "The server installation succeeded, but public HTTPS is not verified yet: $($_.Exception.Message)"
        Write-Host 'Check that the domain A record points to NYC1, any AAAA record also reaches NYC1, and ports 80/443 reach Caddy.'
        Write-Host 'Server certificate logs: ssh nyc1 "sudo journalctl -u caddy -n 40 --no-pager"'
    }
}
