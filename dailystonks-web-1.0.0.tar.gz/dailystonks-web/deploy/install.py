#!/usr/bin/env python3
"""Transactional installer for an existing Ubuntu/Debian Caddy + systemd host."""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import glob
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import urllib.request
from dataclasses import dataclass
from urllib.parse import urlsplit

BASE = Path("/opt/dailystonks-web")
BACKUPS = Path("/var/backups/dailystonks-web")
UNIT = Path("/etc/systemd/system/dailystonks-web.service")
CONFIG = Path("/etc/dailystonks-web/config.json")
SNIPPET = Path("/etc/dailystonks-web/Caddyfile")
STATE = Path("/var/lib/dailystonks-web")
USER = "dailystonks-www"
SERVICE = "dailystonks-web.service"
TARGETS = {"dailystonks.org", "www.dailystonks.org"}
PORT = 8794


def run(args, check=True):
    result = subprocess.run([str(arg) for arg in args], text=True, capture_output=True)
    if check and result.returncode:
        raise RuntimeError(f"{' '.join(str(arg) for arg in args)} failed:\n{result.stderr or result.stdout}")
    return result


@dataclass
class Token:
    value: str
    start: int
    end: int
    line: int
    structural: bool = False


def tokenize(text):
    """Lex only enough to locate top-level blocks; preserve every untouched byte."""
    tokens = []
    pos, line = 0, 1
    while pos < len(text):
        if text[pos].isspace():
            line += text[pos] == "\n"
            pos += 1
            continue
        if text[pos] == "#":
            pos = text.find("\n", pos)
            if pos < 0:
                break
            continue
        start, start_line = pos, line
        if text[pos] in ('"', '`'):
            quote = text[pos]
            pos += 1
            while pos < len(text):
                if quote == '"' and text[pos] == "\\":
                    pos += 2
                    continue
                if text[pos] == quote:
                    pos += 1
                    break
                line += text[pos] == "\n"
                pos += 1
            else:
                raise RuntimeError("Unterminated Caddyfile quote; no changes made")
            raw = text[start:pos]
            tokens.append(Token(raw[1:-1], start, pos, start_line))
        else:
            while pos < len(text) and not text[pos].isspace():
                pos += 1
            raw = text[start:pos]
            if raw.startswith("<<"):
                raise RuntimeError("Caddy heredoc detected. This installer will not rewrite that config automatically.")
            tokens.append(Token(raw, start, pos, start_line, raw in ("{", "}")))
    return tokens


def parse_top_level(text):
    tokens = tokenize(text)
    blocks, imports = [], []
    i = 0
    while i < len(tokens):
        first = tokens[i]
        if first.value == "import":
            args = []
            i += 1
            while i < len(tokens) and tokens[i].line == first.line:
                args.append(tokens[i].value)
                i += 1
            if len(args) != 1 or any(mark in args[0] for mark in ("{", "$")):
                raise RuntimeError("Complex top-level Caddy import; refusing to guess its expansion")
            imports.append(args[0])
            continue
        header = []
        while i < len(tokens) and not (tokens[i].structural and tokens[i].value == "{"):
            if tokens[i].structural:
                raise RuntimeError("Unexpected Caddy closing brace")
            header.append(tokens[i])
            i += 1
        if i == len(tokens):
            raise RuntimeError("Brace-less/fragment Caddy configuration found. Explicit site blocks are required for safe automatic installation.")
        opening = tokens[i]
        depth = 1
        i += 1
        while i < len(tokens) and depth:
            token = tokens[i]
            if token.structural:
                depth += 1 if token.value == "{" else -1
            i += 1
        if depth:
            raise RuntimeError("Unbalanced Caddy braces")
        blocks.append((header, opening, tokens[i - 1]))
    return blocks, imports


def address_host(value):
    value = value.rstrip(",")
    if not value or value.startswith("("):
        return None
    try:
        return urlsplit(value if "://" in value else "//" + value).hostname
    except ValueError:
        return None


def remove_target_blocks(text):
    edits = []
    blocks, _ = parse_top_level(text)
    for header, opening, closing in blocks:
        if not header or not any(address_host(token.value) in TARGETS for token in header):
            continue
        remaining = [token.value.rstrip(",") for token in header
                     if token.value.rstrip(",") and address_host(token.value) not in TARGETS]
        if remaining:
            edits.append((header[0].start, opening.start, ", ".join(remaining) + " "))
        else:
            edits.append((header[0].start, closing.end, "# DailyStonks moved to /etc/dailystonks-web/Caddyfile"))
    for start, end, replacement in reversed(edits):
        text = text[:start] + replacement + text[end:]
    return text


def collect_configs(root):
    found = {}

    def visit(path):
        path = path.resolve()
        if path in found:
            return
        if len(found) >= 100:
            raise RuntimeError("More than 100 Caddy imports; refusing automatic configuration changes")
        text = path.read_text()
        found[path] = text
        _, imports = parse_top_level(text)
        for pattern in imports:
            candidate = Path(pattern) if Path(pattern).is_absolute() else path.parent / pattern
            # Named snippets are not filesystem imports.
            for item in sorted(glob.glob(str(candidate))):
                imported = Path(item)
                if imported.is_file():
                    visit(imported)
    visit(root)
    return found


def write_atomic(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".dailystonks-tmp")
    with temp.open("wb") as file:
        file.write(data if isinstance(data, bytes) else data.encode())
        file.flush()
        os.fsync(file.fileno())
    temp.chmod(mode)
    os.replace(temp, path)


def link_current(target):
    temp = BASE / "current.next"
    temp.unlink(missing_ok=True)
    temp.symlink_to(target)
    os.replace(temp, BASE / "current")


def backup(paths, caddyfile):
    BACKUPS.mkdir(parents=True, exist_ok=True, mode=0o700)
    directory = BACKUPS / (dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + f"-{os.getpid()}")
    directory.mkdir(mode=0o700)
    current = BASE / "current"
    if current.exists() and not current.is_symlink():
        raise RuntimeError(f"{current} is not a symlink; refusing to replace it")
    manifest = {"files": [], "current": os.readlink(current) if current.is_symlink() else None,
                "caddyfile": str(caddyfile), "active": run(["systemctl", "is-active", "--quiet", SERVICE], False).returncode == 0,
                "enabled": run(["systemctl", "is-enabled", "--quiet", SERVICE], False).returncode == 0}
    for index, path in enumerate(dict.fromkeys(paths)):
        record = {"path": str(path), "exists": path.exists()}
        if path.exists():
            stat = path.stat()
            destination = f"file-{index}"
            shutil.copyfile(path, directory / destination)
            (directory / destination).chmod(0o600)
            record.update({"copy": destination, "mode": stat.st_mode & 0o777, "uid": stat.st_uid, "gid": stat.st_gid})
        manifest["files"].append(record)
    write_atomic(directory / "manifest.json", json.dumps(manifest, indent=2), 0o600)
    return directory


def restore(directory):
    directory = directory.resolve()
    if directory.parent != BACKUPS.resolve() or not (directory / "manifest.json").is_file():
        raise RuntimeError("Rollback path must be an installer backup under /var/backups/dailystonks-web")
    manifest = json.loads((directory / "manifest.json").read_text())
    run(["systemctl", "stop", SERVICE], False)
    for record in manifest["files"]:
        path = Path(record["path"])
        if record["exists"]:
            write_atomic(path, (directory / record["copy"]).read_bytes(), record["mode"])
            os.chown(path, record["uid"], record["gid"])
        else:
            path.unlink(missing_ok=True)
    current = BASE / "current"
    if manifest["current"]:
        link_current(manifest["current"])
    else:
        current.unlink(missing_ok=True)
    # Disable before daemon-reload if the previous state had no unit file.
    if not manifest["enabled"]:
        run(["systemctl", "disable", SERVICE], False)
    run(["systemctl", "daemon-reload"])
    if manifest["enabled"]:
        run(["systemctl", "enable", SERVICE])
    if manifest["active"]:
        run(["systemctl", "start", SERVICE])
    run(["caddy", "validate", "--config", manifest["caddyfile"], "--adapter", "caddyfile"])
    run(["systemctl", "reload", "caddy"])
    print(f"Restored configuration and previous service state from {directory}", flush=True)


def safe_extract(archive, destination):
    with tarfile.open(archive, "r:gz") as tar:
        total = 0
        for member in tar.getmembers():
            path = Path(member.name)
            total += member.size
            if path.is_absolute() or ".." in path.parts or not (member.isfile() or member.isdir()) or total > 20_000_000:
                raise RuntimeError("Unsafe or oversized deployment archive")
            target = destination / path
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                target.chmod(0o755)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with tar.extractfile(member) as source, target.open("wb") as output:
                    shutil.copyfileobj(source, output)
                target.chmod(0o644)


def health(timeout=20):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/health", timeout=2) as response:
                value = json.load(response)
            if value.get("app") == "dailystonks-web" and value.get("ok"):
                return value
        except (OSError, ValueError):
            time.sleep(0.5)
    raise RuntimeError("DailyStonks service did not become healthy. Check journalctl -u dailystonks-web.")


def install(args):
    caddyfile = args.caddyfile.resolve()
    if not caddyfile.is_file():
        raise RuntimeError(f"Caddy configuration missing: {caddyfile}")
    for tool in ("caddy", "systemctl", "useradd"):
        if not shutil.which(tool):
            raise RuntimeError(f"Required existing server command is unavailable: {tool}. Nothing installed.")
    command = run(["systemctl", "show", "caddy", "--property=ExecStart", "--value"]).stdout
    if str(caddyfile) not in command:
        raise RuntimeError(f"Caddy's ExecStart does not name {caddyfile}. Use -Caddyfile with its real config path; no changes made.")
    reload_command = run(["systemctl", "show", "caddy", "--property=ExecReload", "--value"]).stdout
    if str(caddyfile) not in reload_command:
        raise RuntimeError("Caddy's ExecReload does not name this Caddyfile; refusing to reload a different configuration")
    run(["systemctl", "is-active", "--quiet", "caddy"])
    run(["caddy", "validate", "--config", caddyfile, "--adapter", "caddyfile"])
    configs = collect_configs(caddyfile)
    if args.audit:
        print("Caddy source:", caddyfile)
        for path, text in configs.items():
            blocks, _ = parse_top_level(text)
            addresses = [token.value for header, _, _ in blocks for token in header
                         if address_host(token.value) in TARGETS]
            print(f"  {path}: {', '.join(addresses) or 'no DailyStonks site block'}")
        print("Audit only. No changes made.")
        return
    archive = args.archive.resolve()
    if hashlib.sha256(archive.read_bytes()).hexdigest() != args.sha256.lower():
        raise RuntimeError("Archive SHA-256 mismatch; nothing installed")
    global PORT
    if CONFIG.exists():
        config = json.loads(CONFIG.read_text())
        PORT = int(config.get("port", PORT))
        if config.get("state_dir", str(STATE)) != str(STATE):
            raise RuntimeError("Custom state_dir found; refusing to change it implicitly")
    if not 1024 <= PORT <= 65535:
        raise RuntimeError("Invalid service port")
    # A port already belonging to this managed service is safe to reuse.
    managed_active = run(["systemctl", "is-active", "--quiet", SERVICE], False).returncode == 0
    if not managed_active:
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", PORT))
    updated = {path: remove_target_blocks(text) for path, text in configs.items() if path != SNIPPET}
    updated = {path: text for path, text in updated.items() if text != configs[path]}
    if SNIPPET not in configs:
        root_text = updated.get(caddyfile, configs[caddyfile])
        updated[caddyfile] = root_text.rstrip() + f"\n\n# Managed DailyStonks Web\nimport {SNIPPET}\n"
    updated[SNIPPET] = f"dailystonks.org {{\n    encode zstd gzip\n    reverse_proxy 127.0.0.1:{PORT}\n}}\n\nwww.dailystonks.org {{\n    redir https://dailystonks.org{{uri}} permanent\n}}\n"
    saved = backup([*updated.keys(), UNIT, CONFIG], caddyfile)
    print(f"Backup: {saved}", flush=True)
    try:
        stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        release = BASE / "releases" / (stamp + f"-{os.getpid()}")
        release.mkdir(parents=True)
        for directory in (BASE, BASE / "releases", release):
            directory.chmod(0o755)
        safe_extract(archive, release)
        for required in ("app/server.py", "app/market.py", "public/index.html", "public/app.js", "public/style.css"):
            if not (release / required).is_file():
                raise RuntimeError(f"Missing deployment file: {required}")
        try:
            account = pwd.getpwnam(USER)
        except KeyError:
            run(["useradd", "--system", "--home-dir", STATE, "--no-create-home", "--shell", "/usr/sbin/nologin", USER])
            account = pwd.getpwnam(USER)
        if account.pw_uid == 0:
            raise RuntimeError("Service account unexpectedly has root UID")
        STATE.mkdir(parents=True, exist_ok=True, mode=0o750)
        os.chown(STATE, account.pw_uid, account.pw_gid)
        if not CONFIG.exists():
            write_atomic(CONFIG, json.dumps({"port": PORT, "state_dir": str(STATE), "refresh_seconds": 60, "history_refresh_seconds": 900}, indent=2))
        unit = f"""[Unit]
Description=DailyStonks Web market observatory
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={USER}
Group={account.pw_gid}
WorkingDirectory={BASE}/current
ExecStart=/usr/bin/python3 -B {BASE}/current/app/server.py --config {CONFIG}
Environment=PYTHONUNBUFFERED=1
Restart=on-failure
RestartSec=5
TimeoutStopSec=20
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
ReadWritePaths={STATE}
UMask=0027
MemoryMax=256M
TasksMax=64

[Install]
WantedBy=multi-user.target
"""
        write_atomic(UNIT, unit)
        link_current(release)
        run(["systemctl", "daemon-reload"])
        run(["systemctl", "enable", SERVICE])
        run(["systemctl", "restart", SERVICE])
        health()
        for path, text in updated.items():
            if path in configs:
                stat = path.stat()
                write_atomic(path, text, stat.st_mode & 0o777)
                os.chown(path, stat.st_uid, stat.st_gid)
            else:
                write_atomic(path, text)
        run(["caddy", "validate", "--config", caddyfile, "--adapter", "caddyfile"])
        run(["systemctl", "reload", "caddy"])
        # Wait at most 35 seconds for the first independent provider poll.
        deadline = time.monotonic() + 35
        status = health()
        while not status["available"] and not status["errors"] and time.monotonic() < deadline:
            time.sleep(1)
            status = health()
        print("Service healthy; Caddy validated and reloaded.")
        print("Available market feeds:", ", ".join(status["available"]) or "still loading")
        if status["errors"]:
            print("FEED WARNING:", json.dumps(status["errors"]))
        try:
            addresses = sorted({item[4][0] for item in socket.getaddrinfo("dailystonks.org", 443, type=socket.SOCK_STREAM)})
            print("Domain DNS:", ", ".join(addresses))
        except OSError:
            print("DNS WARNING: dailystonks.org did not resolve from the server")
        print("Ready at https://dailystonks.org once its DNS reaches this server and Caddy obtains its certificate.")
        print(f"Rollback backup: {saved}")
    except BaseException:
        print("Deployment failed. Restoring the saved configuration…", flush=True)
        try:
            restore(saved)
        except Exception as exc:
            print(f"ROLLBACK ERROR: {exc}\nBackup retained at {saved}", file=sys.stderr)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--sha256", default="")
    parser.add_argument("--caddyfile", type=Path, default=Path("/etc/caddy/Caddyfile"))
    parser.add_argument("--audit", action="store_true")
    parser.add_argument("--rollback", type=Path)
    args = parser.parse_args()
    if os.geteuid() != 0:
        parser.error("Run through sudo; this installer needs to manage Caddy and systemd")
    if sys.version_info < (3, 10):
        parser.error("Python 3.10 or newer is required")
    if not args.rollback and not args.audit and (not args.archive or not re.fullmatch(r"[0-9a-fA-F]{64}", args.sha256)):
        parser.error("Deployment requires --archive and its --sha256")
    with open("/run/lock/dailystonks-web.lock", "w") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.error("Another DailyStonks installation is already running")
        try:
            restore(args.rollback) if args.rollback else install(args)
        except Exception as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
