#!/usr/bin/env python3
"""Rebuild site.tar.gz from actual source; no third-party tools required."""
import hashlib
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
paths = [*sorted((root / "app").glob("*.py")),
         *sorted((root / "public").glob("*")), root / "README.md", root / "LICENSE"]
archive = root / "site.tar.gz"
temporary = archive.with_suffix(".tmp")
with tarfile.open(temporary, "w:gz") as output:
    for path in paths:
        if not path.is_file():
            raise SystemExit(f"Required source file missing: {path}")
        output.add(path, arcname=path.relative_to(root), recursive=False)
temporary.replace(archive)
print(f"Built {archive.name}: {archive.stat().st_size:,} bytes")
print(f"SHA256 {hashlib.sha256(archive.read_bytes()).hexdigest()}")
