'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const KEYS = ['SPX', 'SPY', 'BTC'];
  const COLORS = {SPX: '#93d9bf', SPY: '#b5a0ec', BTC: '#edbd6e'};
  const state = {data: null, months: 6, visible: new Set(KEYS), forecast: true, band: false, volume: true, hover: null, view: null, busy: false, disconnected: false};
  const money = value => Number.isFinite(value) ? value.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}) : '—';
  const percent = value => { if (!Number.isFinite(value)) return '—'; const rounded = Math.abs(value) < 0.005 ? 0 : value; return `${rounded >= 0 ? '+' : ''}${rounded.toFixed(2)}%`; };
  const dateMs = date => Date.parse(`${date}T00:00:00Z`);
  const dateText = date => new Date(dateMs(date)).toLocaleDateString('en-GB', {day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});
  const quoteText = seconds => new Date(seconds * 1000).toLocaleString('en-GB', {day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',timeZone:'UTC'}) + ' UTC';
  const el = (tag, text, className) => { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; if (className) node.className = className; return node; };
  const getAsset = key => state.data?.assets.find(asset => asset.key === key);
  const signedClass = value => value >= 0 ? 'positive' : 'negative';

  function fitCanvas(canvas) {
    const box = canvas.getBoundingClientRect(), ratio = Math.min(window.devicePixelRatio || 1, 3);
    const width = Math.max(1, box.width), height = Math.max(1, box.height);
    canvas.width = Math.round(width * ratio); canvas.height = Math.round(height * ratio);
    const ctx = canvas.getContext('2d'); ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    return {ctx, width, height};
  }

  function spark(key) {
    const asset = getAsset(key), {ctx, width, height} = fitCanvas($(`spark-${key}`));
    if (!asset) return;
    const prices = asset.bars.slice(-30).map(bar => bar.close), lo = Math.min(...prices), span = Math.max(...prices) - lo || 1;
    ctx.strokeStyle = COLORS[key]; ctx.lineWidth = 1.5; ctx.beginPath();
    prices.forEach((price, i) => { const x = i / Math.max(prices.length - 1, 1) * width, y = height - 4 - (price - lo) / span * (height - 8); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
    ctx.stroke();
  }

  function updateCards() {
    KEYS.forEach(key => {
      const asset = getAsset(key); spark(key);
      if (!asset) return;
      $(`price-${key}`).textContent = `${key === 'SPX' ? '' : '$'}${money(asset.quote.price)}`;
      const change = $(`change-${key}`);
      change.textContent = `${percent(asset.quote.change_pct)} day`; change.className = signedClass(asset.quote.change_pct);
      $(`time-${key}`).textContent = quoteText(asset.quote.time);
    });
    const list = $('forecast-values'); list.replaceChildren();
    KEYS.forEach(key => {
      const asset = getAsset(key), forecast = asset?.forecast, cell = el('div', undefined, `forecast-cell ${key.toLowerCase()}`);
      cell.append(el('span', key === 'SPX' ? 'S&P 500' : key), el('b', forecast ? percent((forecast.points.at(-1).close / forecast.last_close - 1) * 100) : '—'));
      cell.append(el('small', forecast ? `by ${dateText(forecast.points.at(-1).date).replace(/ \d{4}$/, '')}` : 'Feed unavailable'));
      cell.title = forecast ? `Projected price ${money(forecast.points.at(-1).close)}; change from the last completed close, ${dateText(forecast.last_date)}. ${forecast.observations} observations fitted.` : 'Not enough completed history';
      list.append(cell);
    });
    const spx = getAsset('SPX'), now = state.data.server_time;
    $('session-label').textContent = spx ? (now >= spx.quote.session_start && now < spx.quote.session_end ? 'US regular session open' : 'US regular session closed') + ' · Crypto trades 24/7' : 'US session unavailable · Crypto trades 24/7';
  }

  function updateTape() {
    const first = $('ticker-set'); first.replaceChildren();
    state.data.assets.forEach(asset => {
      const item = el('span', undefined, 'ticker-item');
      item.title = `${asset.name} · ${quoteText(asset.quote.time)}${state.data.errors[asset.key] ? ' · Last good quote; feed error' : ''}`;
      item.append(el('b', asset.key), el('span', money(asset.quote.price)), el('small', percent(asset.quote.change_pct), signedClass(asset.quote.change_pct)));
      first.append(item);
    });
    if (!first.children.length) first.append(el('span', 'Price feed unavailable. Retrying automatically.', 'ticker-wait'));
    $('ticker-track').querySelectorAll('[data-copy]').forEach(copy => copy.remove());
    if (state.data.assets.length) {
      const copy = first.cloneNode(true); copy.removeAttribute('id'); copy.dataset.copy = 'true'; copy.setAttribute('aria-hidden', 'true');
      $('ticker-track').append(copy);
    }
  }

  function makeView() {
    if (!state.data) return null;
    const cutoff = new Date(state.data.server_time * 1000); cutoff.setUTCMonth(cutoff.getUTCMonth() - state.months);
    const cutoffDate = cutoff.toISOString().slice(0,10);
    const available = KEYS.map(getAsset).filter(Boolean);
    if (!available.length) return null;
    const lists = available.map(asset => asset.bars.filter(bar => bar.date >= cutoffDate));
    const common = lists[0].map(bar => bar.date).find(date => lists.every(rows => rows.some(row => row.date === date)));
    if (!common) return null;
    const series = available.map(asset => ({...asset, rows: asset.bars.filter(bar => bar.date >= common), base: asset.bars.find(bar => bar.date === common).close}));
    const dates = [...new Set(series.flatMap(asset => asset.rows.map(bar => bar.date)))].sort();
    if (dates.length < 2) return null;
    return {series, dates, base: common};
  }

  function draw() {
    const canvas = $('chart'), {ctx, width: w, height: h} = fitCanvas(canvas);
    state.view = makeView();
    const view = state.view, empty = $('chart-empty');
    empty.hidden = !!view;
    if (!view) {
      if (state.data?.last_poll || state.disconnected) {
        empty.querySelector('strong').textContent = 'The feed is taking a breather.';
        empty.querySelector('p').textContent = 'Market history is unavailable right now. This page retries automatically; prices will appear when the feed returns.';
      }
      return;
    }
    $('base-label').textContent = `Price performance · 0% = close on ${dateText(view.base)} · UTC dates`;
    const active = view.series.filter(asset => state.visible.has(asset.key));
    const left = w < 550 ? 49 : 63, right = w - (w < 550 ? 15 : 25), top = 32;
    const volumeHeight = state.volume && state.visible.has('SPX') ? 60 : 0;
    const bottom = h - 38 - volumeHeight, volumeBottom = h - 34;
    const start = dateMs(view.base), lastReal = Math.max(...view.dates.map(dateMs));
    let end = lastReal;
    const extrema = [0];
    active.forEach(asset => {
      asset.rows.forEach(row => { extrema.push((row.low / asset.base - 1) * 100, (row.high / asset.base - 1) * 100); });
      if (state.forecast && asset.forecast) asset.forecast.points.forEach(point => {
        end = Math.max(end, dateMs(point.date));
        extrema.push((point.close / asset.base - 1) * 100);
        if (state.band) extrema.push((point.low / asset.base - 1) * 100, (point.high / asset.base - 1) * 100);
      });
    });
    let low = Math.min(...extrema), high = Math.max(...extrema);
    const padding = Math.max((high - low) * 0.13, 1); low -= padding; high += padding;
    const x = date => left + (dateMs(date) - start) / Math.max(end - start, 86400000) * (right - left);
    const y = value => bottom - (value - low) / (high - low) * (bottom - top);
    const norm = (value, asset) => (value / asset.base - 1) * 100;
    view.plot = {x,y,left,right,top,bottom,volumeBottom,w,h,start,end};
    ctx.font = '10px ui-monospace, Consolas, monospace'; ctx.textBaseline = 'middle';
    if (end > lastReal) {
      const futureX = left + (lastReal - start) / (end - start) * (right - left);
      ctx.fillStyle = '#c6f77b05'; ctx.fillRect(futureX, top, right - futureX, volumeBottom - top);
      ctx.strokeStyle = '#42503a'; ctx.setLineDash([3,5]); ctx.beginPath(); ctx.moveTo(futureX, top); ctx.lineTo(futureX, volumeBottom); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = '#78876e'; ctx.font = '8px ui-monospace, Consolas, monospace';
      if (right - futureX > 54) ctx.fillText('OUTLOOK', futureX + 8, top - 12);
    }
    ctx.font = '9px ui-monospace, Consolas, monospace';
    for (let i = 0; i <= 5; i++) {
      const value = low + (high - low) * i / 5, yy = y(value);
      ctx.strokeStyle = '#263127'; ctx.setLineDash([2,5]); ctx.beginPath(); ctx.moveTo(left, yy); ctx.lineTo(right, yy); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = '#81917c'; ctx.textAlign = 'right'; ctx.fillText(`${value > 0 ? '+' : ''}${value.toFixed(1)}%`, left - 10, yy);
    }
    ctx.strokeStyle = '#56634b'; ctx.setLineDash([4,5]); ctx.beginPath(); ctx.moveTo(left, y(0)); ctx.lineTo(right, y(0)); ctx.stroke(); ctx.setLineDash([]);
    const ticks = w < 550 ? 4 : 7;
    for (let i = 0; i < ticks; i++) {
      const xx = left + i / (ticks - 1) * (right - left), stamp = start + i / (ticks - 1) * (end - start);
      ctx.textAlign = i === 0 ? 'left' : i === ticks - 1 ? 'right' : 'center'; ctx.fillStyle = '#81917c';
      ctx.fillText(new Date(stamp).toLocaleDateString('en-GB',{day:'numeric',month:'short',timeZone:'UTC'}), xx, h - 13);
      ctx.strokeStyle = '#1d2820'; ctx.beginPath(); ctx.moveTo(xx, top); ctx.lineTo(xx, volumeBottom); ctx.stroke();
    }
    ctx.save(); ctx.beginPath(); ctx.rect(left, top - 1, right - left + 1, bottom - top + 2); ctx.clip();
    active.forEach(asset => {
      const color = COLORS[asset.key];
      if (state.forecast && asset.forecast && state.band) {
        const points = asset.forecast.points;
        ctx.fillStyle = `${color}15`; ctx.beginPath();
        points.forEach((point,i) => { const xx=x(point.date), yy=y(norm(point.high,asset)); i ? ctx.lineTo(xx,yy) : ctx.moveTo(xx,yy); });
        [...points].reverse().forEach(point => ctx.lineTo(x(point.date), y(norm(point.low,asset)))); ctx.closePath(); ctx.fill();
      }
      if (asset.key === 'SPX') {
        const candleWidth = Math.max(1,Math.min(6,(right-left)/((end-start)/86400000)*0.58));
        asset.rows.forEach(row => {
          const xx=x(row.date), yo=y(norm(row.open,asset)), yc=y(norm(row.close,asset));
          ctx.strokeStyle = row.close >= row.open ? '#93d9bfa0' : '#ed8b88a0'; ctx.fillStyle=ctx.strokeStyle; ctx.lineWidth=1;
          ctx.beginPath(); ctx.moveTo(xx,y(norm(row.high,asset))); ctx.lineTo(xx,y(norm(row.low,asset))); ctx.stroke();
          ctx.fillRect(xx-candleWidth/2,Math.min(yo,yc),candleWidth,Math.max(1,Math.abs(yc-yo)));
        });
      } else {
        ctx.strokeStyle=color; ctx.lineWidth=1.6; ctx.beginPath();
        asset.rows.forEach((row,i) => i ? ctx.lineTo(x(row.date),y(norm(row.close,asset))) : ctx.moveTo(x(row.date),y(norm(row.close,asset)))); ctx.stroke();
      }
      if (state.forecast && asset.forecast) {
        const forecast = asset.forecast;
        ctx.strokeStyle=color; ctx.lineWidth=1.5; ctx.setLineDash([5,5]); ctx.beginPath(); ctx.moveTo(x(forecast.last_date),y(norm(forecast.last_close,asset)));
        forecast.points.forEach(point => ctx.lineTo(x(point.date),y(norm(point.close,asset)))); ctx.stroke(); ctx.setLineDash([]);
        const endpoint=forecast.points.at(-1); ctx.fillStyle=color; ctx.beginPath(); ctx.arc(x(endpoint.date),y(norm(endpoint.close,asset)),2.5,0,2*Math.PI); ctx.fill();
      }
    });
    ctx.restore();
    if (volumeHeight) {
      const spx=view.series.find(asset=>asset.key==='SPX');
      if (spx) {
        const maxVolume=Math.max(1,...spx.rows.map(row=>row.volume || 0));
        const barWidth=Math.max(1,Math.min(6,(right-left)/((end-start)/86400000)*0.58));
        spx.rows.forEach(row=>{if(row.volume===null)return;ctx.fillStyle=row.close>=row.open?'#93d9bf35':'#ed8b8835'; const vh=row.volume/maxVolume*(volumeHeight-17);ctx.fillRect(x(row.date)-barWidth/2,volumeBottom-vh,barWidth,vh);});
        ctx.fillStyle='#6e8068';ctx.textAlign='left';ctx.font='8px ui-monospace, Consolas, monospace';ctx.fillText('S&P VOLUME',left,bottom+13);
      }
    }
    if (!active.length) {ctx.fillStyle='#a9b7a1';ctx.textAlign='center';ctx.fillText('Select a market card to show a layer.',w/2,(top+bottom)/2);}
    drawHover(ctx);
  }

  function drawHover(ctx) {
    const view=state.view, tip=$('tooltip');
    if (!state.hover || !view?.plot) { tip.hidden=true;return; }
    const {x,y,top,volumeBottom,left,right,w}=view.plot, date=state.hover, xx=x(date);
    if(xx<left||xx>right){tip.hidden=true;return;}
    ctx.strokeStyle='#b6c5a166';ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(xx,top);ctx.lineTo(xx,volumeBottom);ctx.stroke();ctx.setLineDash([]);
    tip.replaceChildren(el('strong',dateText(date)));
    view.series.filter(asset=>state.visible.has(asset.key)).forEach(asset=>{
      const row=asset.rows.find(row=>row.date===date), future=state.forecast&&asset.forecast?.points.find(point=>point.date===date);
      const point=row||future, line=el('div',undefined,'tip-row');
      line.style.color=COLORS[asset.key];line.append(el('span',asset.key+(future?' est.':'')),el('span',point?money(point.close):'No session'));tip.append(line);
      if(point){const yy=y((point.close/asset.base-1)*100);ctx.fillStyle=COLORS[asset.key];ctx.beginPath();ctx.arc(xx,yy,3,0,2*Math.PI);ctx.fill();}
    });
    tip.append(el('div','USD / index points · daily close','tip-note'));tip.hidden=false;
    tip.style.left=`${Math.max(4,Math.min(w-220,xx+18))}px`;tip.style.top='45px';
  }

  function tableRows() {
    const view=state.view;if(!view)return[];
    return view.dates.map(date=>[date,...KEYS.map(key=>view.series.find(asset=>asset.key===key)?.rows.find(row=>row.date===date)?.close??null)]);
  }
  function updateTable() {
    const body=$('data-table');body.replaceChildren();
    tableRows().reverse().forEach(row=>{const tr=el('tr');row.forEach((value,i)=>tr.append(el('td',i===0?value:money(value))));body.append(tr);});
  }

  function updateStatus() {
    if(!state.data)return;
    const failures=Object.keys(state.data.errors), missing=KEYS.filter(key=>!getAsset(key));
    const stale=state.data.assets.filter(asset=>state.data.server_time-asset.fetched_at>Math.max(state.data.refresh_seconds*3,180)).map(asset=>asset.key);
    const warning=state.disconnected||failures.length||missing.length||stale.length;
    $('feed-status').textContent=state.disconnected?'CONNECTION LOST':warning?'FEED DEGRADED':'AUTO UPDATE · 60S';
    const note=$('feed-note');note.classList.toggle('warning',!!warning);
    const messages=['Prices: Yahoo Finance · provider delays apply · individual quote times shown above.'];
    if(state.disconnected)messages.push('Connection to this server failed. Displaying the last received snapshot; retrying automatically.');
    if(failures.length)messages.push(`Provider error: ${failures.join(', ')}. Last good prices are retained where available.`);
    if(missing.length)messages.push(`Missing chart layers: ${missing.join(', ')}.`);
    if(stale.length)messages.push(`Stale feed snapshots: ${stale.join(', ')}.`);
    messages.push('No simulated prices.');note.textContent=messages.join(' ');
    $('chart-update').textContent=state.data.last_poll?`Server poll ${new Date(state.data.last_poll*1000).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit',timeZone:'UTC'})} UTC · quote times differ`:'First shared provider poll in progress…';
  }

  let timer;
  async function load() {
    if(state.busy)return;state.busy=true;$('refresh').disabled=true;clearTimeout(timer);
    try{
      const response=await fetch('/api/market',{cache:'no-store',signal:AbortSignal.timeout(15000)});
      if(!response.ok)throw new Error(`HTTP ${response.status}`);
      const data=await response.json();if(!Array.isArray(data.assets)||!Number.isFinite(data.server_time))throw new Error('Invalid snapshot');
      state.data=data;state.disconnected=false;updateCards();updateTape();draw();updateTable();updateStatus();
    }catch(error){
      state.disconnected=true;$('feed-status').textContent='CONNECTION LOST';
      if(state.data)updateStatus();else{$('feed-note').textContent='The market service is unavailable. Retrying automatically; no sample prices are displayed.';draw();}
    }finally{state.busy=false;$('refresh').disabled=false;timer=setTimeout(load,state.data?.last_poll?15000:2500);}
  }

  document.querySelectorAll('[data-key]').forEach(button=>button.addEventListener('click',()=>{
    const key=button.dataset.key;state.visible.has(key)?state.visible.delete(key):state.visible.add(key);button.setAttribute('aria-pressed',String(state.visible.has(key)));draw();
  }));
  document.querySelectorAll('[data-range]').forEach(button=>button.addEventListener('click',()=>{
    state.months=Number(button.dataset.range);state.hover=null;document.querySelectorAll('[data-range]').forEach(item=>item.setAttribute('aria-pressed',String(item===button)));draw();updateTable();
  }));
  [['forecast-toggle','forecast'],['band-toggle','band'],['volume-toggle','volume']].forEach(([id,key])=>$(id).addEventListener('change',event=>{state[key]=event.target.checked;draw();}));
  $('refresh').addEventListener('click',load);
  $('pause-tape').addEventListener('click',()=>{const paused=document.querySelector('.ticker').classList.toggle('paused');$('pause-tape').setAttribute('aria-pressed',String(paused));$('pause-tape').textContent=paused?'Resume ticker ▷':'Pause ticker Ⅱ';});
  $('download').addEventListener('click',()=>{
    const rows=tableRows();if(!rows.length)return;
    const csv='Date_UTC,SPX_close_points,SPY_close_USD,BTC_close_USD\r\n'+rows.map(row=>row.map(value=>value??'').join(',')).join('\r\n');
    const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),link=el('a');link.href=url;link.download='dailystonks-daily-closes.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  const chart=$('chart');
  chart.addEventListener('pointermove',event=>{
    const view=state.view;if(!view?.plot)return;const box=chart.getBoundingClientRect(),xx=event.clientX-box.left;
    const candidates=[...view.dates];if(state.forecast)view.series.forEach(asset=>asset.forecast?.points.forEach(point=>candidates.push(point.date)));
    state.hover=candidates.reduce((best,date)=>Math.abs(view.plot.x(date)-xx)<Math.abs(view.plot.x(best)-xx)?date:best,candidates[0]);draw();
  });
  chart.addEventListener('pointerleave',()=>{state.hover=null;draw();});
  chart.addEventListener('keydown',event=>{
    if(!['ArrowLeft','ArrowRight','Escape'].includes(event.key)||!state.view)return;event.preventDefault();
    if(event.key==='Escape')state.hover=null;else{const dates=state.view.dates,index=state.hover?dates.indexOf(state.hover):dates.length-1;state.hover=dates[Math.max(0,Math.min(dates.length-1,index+(event.key==='ArrowRight'?1:-1)))];}draw();
  });
  let resizeTimer;new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{KEYS.forEach(spark);draw();},60);}).observe($('canvas-wrap'));
  function clock(){const now=new Date();$('clock').textContent=now.toLocaleTimeString('en-GB',{timeZone:'UTC'})+' UTC';$('edition-date').textContent=now.toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'UTC'}).toUpperCase();$('year').textContent=now.getUTCFullYear();}
  clock();setInterval(clock,1000);load();
})();
